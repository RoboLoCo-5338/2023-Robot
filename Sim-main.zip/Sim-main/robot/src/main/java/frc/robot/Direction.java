package frc.robot;

public enum Direction {
    LEFT, RIGHT, FORWARD, BACKWARD
}
