package frc.robot;

import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command.InterruptionBehavior;

import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj2.command.button.JoystickButton;
import frc.robot.subsystems.Affector;
import frc.robot.subsystems.Limelight;
import frc.robot.subsystems.Elevator;
import frc.robot.subsystems.ExampleSubsystem;
import frc.robot.commands.PIDCommand1;

import frc.robot.commands.Autos;
import frc.robot.commands.ExampleCommand;
import frc.robot.subsystems.Drivetrain;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj2.command.RunCommand;
import edu.wpi.first.wpilibj2.command.button.CommandXboxController;
import edu.wpi.first.wpilibj2.command.button.Trigger;

/**
 * This class is where the bulk of the robot should be declared. Since
 * Command-based is a
 * "declarative" paradigm, very little robot logic should actually be handled in
 * the {@link Robot}
 * periodic methods (other than the scheduler calls). Instead, the structure of
 * the robot
 * (including subsystems, commands, and button mappings) should be declared
 * here.
 */
public class RobotContainer {
  // Subsystems
  public final Limelight m_limelight = new Limelight();
  public final Elevator m_elevator = new Elevator();
  public final Affector m_affector = new Affector();
  private final ExampleSubsystem m_exampleSubsystem = new ExampleSubsystem();
  public static final Drivetrain drivetrain = new Drivetrain();

  // Joysticks
  private final XboxController xboxController1 = new XboxController(1);

  private static Joystick controller1 = new Joystick(0); // driver
  // private static Joystick controller2 = new Joystick(1); // operator

  // A chooser for autonomous commands
  SendableChooser<Command> m_chooser = new SendableChooser<>();

  /**
   * The container for the robot. Contains subsystems, OI devices, and commands.
   */
  public RobotContainer() {
    // Smartdashboard Subsystems

    // SmartDashboard Buttons
    SmartDashboard.putData("PID Command 1: hLow", new PIDCommand1(Elevator.height1, m_elevator));
    SmartDashboard.putData("PID Command 1: hMid", new PIDCommand1(Elevator.height2, m_elevator));
    SmartDashboard.putData("PID Command 1: hHigh", new PIDCommand1(Elevator.height3, m_elevator));
    SmartDashboard.putData("Auto Mode", m_chooser);

    // Configure the button bindings
    configureButtonBindings();
    configureBindings();
    configureDefaultCommands();
  }

  public Command defaultDrive = new RunCommand(
      () -> drivetrain.tankDrive(
          controller1.getRawAxis(1),
          controller1.getRawAxis(5)),
      drivetrain);

  /**
   * Use this method to define your button->command mappings. Buttons can be
   * created by
   * instantiating a {@link GenericHID} or one of its subclasses ({@link
   * edu.wpi.first.wpilibj.Joystick} or {@link XboxController}), and then passing
   * it to a
   * {@link edu.wpi.first.wpilibj2.command.button.JoystickButton}.
   */
  private void configureButtonBindings() {
    // Create some buttons
    final JoystickButton xboxButtonB = new JoystickButton(xboxController1, XboxController.Button.kB.value);
    xboxButtonB
        .onTrue(new PIDCommand1(Elevator.height3, m_elevator).withInterruptBehavior(InterruptionBehavior.kCancelSelf));

    final JoystickButton xboxButtonY = new JoystickButton(xboxController1, XboxController.Button.kY.value);
    xboxButtonY
        .onTrue(new PIDCommand1(Elevator.height2, m_elevator).withInterruptBehavior(InterruptionBehavior.kCancelSelf));

    final JoystickButton xboxButtonX = new JoystickButton(xboxController1, XboxController.Button.kX.value);
    xboxButtonX
        .onTrue(new PIDCommand1(Elevator.height1, m_elevator).withInterruptBehavior(InterruptionBehavior.kCancelSelf));
  }

  public XboxController getXboxController1() {
    return xboxController1;
  }

  /**
   * Use this method to define your trigger->command mappings. Triggers can be
   * created via the
   * {@link Trigger#Trigger(java.util.function.BooleanSupplier)} constructor with
   * an arbitrary
   * predicate, or via the named factories in {@link
   * edu.wpi.first.wpilibj2.command.button.CommandGenericHID}'s subclasses for
   * {@link
   * CommandXboxController
   * Xbox}/{@link edu.wpi.first.wpilibj2.command.button.CommandPS4Controller
   * PS4} controllers or
   * {@link edu.wpi.first.wpilibj2.command.button.CommandJoystick Flight
   * joysticks}.
   */
  private void configureBindings() {
    // Schedule `ExampleCommand` when `exampleCondition` changes to `true`
    new Trigger(m_exampleSubsystem::exampleCondition)
        .onTrue(new ExampleCommand(m_exampleSubsystem));

    // Schedule `exampleMethodCommand` when the Xbox controller's B button is
    // pressed,
    // cancelling on release.
    // m_driverController.b().whileTrue(m_exampleSubsystem.exampleMethodCommand());
  }

  private void configureDefaultCommands() {
    drivetrain.setDefaultCommand(defaultDrive);
  }

  /**
   * Use this to pass the autonomous command to the main {@link Robot} class.
   *
   * @return the command to run in autonomous
   */
  public Command getAutonomousCommand() {
    // The selected command will be run in autonomous
    return Autos.exampleAuto(m_exampleSubsystem);
  }

}
